<?php

/**
 * Add custom classes to BuddyPress members loop.
 *
 * @param array  $classes   Array of classes.
 * @param string $component BuddyPress component name.
 *
 * @return array
 */
function cozy_community_loop_classes( $classes, $component ) {
	if ( 'members' === $component ) {
		$classes[] = 'cc-grid-four';
	}

	return $classes;
}

add_filter( 'bp_nouveau_get_loop_classes', 'cozy_community_loop_classes', 10, 2 );

/**
 * Filter BuddyPress members loop to hide users with the "hide-from-directory" member type.
 *
 * @param object $query_array The query array for the BuddyPress user query.
 *
 * @return void
 */
function cozy_community_hide_members_loop( $query_array ) {

	$term = get_term_by(
		'slug',
		'hide-from-directory',
		'bp_member_type'
	);

	if ( ! $term || is_wp_error( $term ) ) {
		return;
	}

	$users = get_objects_in_term( $term->term_id, 'bp_member_type' );

	if ( ! $users || is_wp_error( $users ) ) {
		return;
	}

	$existing = isset( $query_array->query_vars['exclude'] )
	? (array) $query_array->query_vars['exclude']
	: array();

	$query_array->query_vars['exclude'] = array_unique(
		array_merge( $existing, (array) $users )
	);
}

add_action( 'bp_pre_user_query_construct', 'cozy_community_hide_members_loop', 8 );
